import java.applet.*;
import java.awt.*;

 

public class Pra1a extends Applet{
    
    public void paint(Graphics g){
        g.drawString("Advance Java",10,10);
    }
}